Research-Grade Computational Physics in Python
The Complete TaN-MM-Org Course - Companion Code Bundle
(c) 2026 Tanvir Mahmud Mahim

One directory per module, one script per lesson, exactly as printed in
the course book. Next to each script, a .out.txt file captures the
verified output the book reproduces.

Setup (Python >= 3.10 recommended):

    python -m pip install hamop kpenvelope ramansep sparq-triage \
                          absnoise cavsqueeze sqzcomb fabtwin

Versions the course was validated against:
    hamop 0.6.0, kpenvelope 0.7.0, ramansep 0.7.0, sparq-triage 0.5.0,
    absnoise 0.6.0, cavsqueeze 1.11.0, sqzcomb 0.8.0, fabtwin 0.2.0

Run any lesson:

    python m1_hamop/lesson_1_1_first_model.py

Every script is self-checking: it asserts its own physics anchors and
prints "OK: lesson X.Y complete" on success. Statistical checks are
seeded, so outputs are reproducible.

License note: these lesson scripts are trivial API usage - reuse them
freely in your research. The packages themselves are Apache-2.0 open
source at github.com/TaN-MM-Org.
