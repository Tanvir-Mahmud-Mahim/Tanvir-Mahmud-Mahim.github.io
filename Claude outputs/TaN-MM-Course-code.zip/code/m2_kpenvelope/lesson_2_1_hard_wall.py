"""Module 2, Lesson 2.1 -- Hole subbands in a hard-wall well
(kpenvelope).

The shipped demo parameter set decouples the six-band Hamiltonian into
identical single-band problems (effective mass m* = m0/|A|), so the
solver's subband energies can be checked against the infinite-well
closed form E_n = -(hbar^2/2m*)(n pi / L)^2 (hole convention: energies
descend). Each level appears six-fold (six decoupled components).
"""
import numpy as np

import kpenvelope
from kpenvelope import HBAR2_OVER_2M0, demo_single_band, solve_subbands

print(f"kpenvelope version: {kpenvelope.__version__}")

A = -2.0
p = demo_single_band(A=A)                 # m*/m0 = 1/|A| = 0.5
L = 8.0                                   # nm
z = np.linspace(0.0, L, 401)
energies, envelopes = solve_subbands(p, z, n_states=18)

print(f"energies shape : {energies.shape}   (descending, hole convention)")
print(f"envelopes shape: {envelopes.shape}  (states, 6 components, grid)")

# closed form: E_n = -|A| * (hbar^2/2m0) * (n pi / L)^2
for n in (1, 2, 3):
    E_exact = -abs(A) * HBAR2_OVER_2M0 * (n * np.pi / L) ** 2
    E_num = energies[6 * (n - 1)]         # each level is six-fold degenerate
    print(f"n={n}: solver {E_num:+.6f} eV | closed form {E_exact:+.6f} eV "
          f"| rel. err {abs(E_num - E_exact) / abs(E_exact):.2e}")
    assert abs(E_num - E_exact) / abs(E_exact) < 2e-2   # grid-limited

# The dominant error is the effective position of the hard wall (the
# discrete boundary sits about one grid spacing outside each end), so
# the level error is FIRST order in dz: halving the spacing halves it.
# Knowing the error's origin and order is what lets you budget a grid.
z_fine = np.linspace(0.0, L, 801)
E_fine, _ = solve_subbands(p, z_fine, n_states=6)
E1_exact = -abs(A) * HBAR2_OVER_2M0 * (np.pi / L) ** 2
err_coarse = abs(energies[0] - E1_exact)
err_fine = abs(E_fine[0] - E1_exact)
print(f"ground-level error, 401 pts: {err_coarse:.2e} eV; "
      f"801 pts: {err_fine:.2e} eV; ratio {err_coarse / err_fine:.1f} "
      f"(first-order boundary error: ~2)")
assert 1.8 < err_coarse / err_fine < 2.2

# six-fold degeneracy of the ground level, exactly
spread = energies[:6].max() - energies[:6].min()
print(f"ground-multiplet spread: {spread:.2e} eV  (six-fold degenerate)")
assert spread < 1e-12

# normalization contract: sum_m integral |F_m|^2 dz = 1
dz = z[1] - z[0]
norm = (np.abs(envelopes[0]) ** 2).sum() * dz
print(f"ground-state norm      : {norm:.12f}")
assert abs(norm - 1.0) < 1e-10
print("OK: lesson 2.1 complete")
