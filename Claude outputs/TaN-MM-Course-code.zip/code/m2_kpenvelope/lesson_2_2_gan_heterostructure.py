"""Module 2, Lesson 2.2 -- Real materials: bulk GaN anchors and an
AlN/GaN/AlN quantum well (kpenvelope).

The cited GaN parameter set (Rinke et al., Phys. Rev. B 77, 075202
(2008)) reproduces the zone-center valence splittings, and
`layered_profile` + `solve_heterostructure` build a finite-barrier
AlN/GaN/AlN well with the symmetrized Ben Daniel-Duke assembly.
"""
import numpy as np

from kpenvelope import (aln_rinke2008, gan_rinke2008, layered_profile,
                        solve_heterostructure, solve_subbands)

# --- bulk GaN zone-center splittings -------------------------------
# The 6x6 bulk block at k = 0 carries the crystal-field/spin-orbit
# structure of the valence edge: A-B and A-C splittings of the Rinke
# set are 5.20 and 21.80 meV (against accepted experimental values
# near 5-6 and 22 meV; the package's test suite pins them to 0.01 meV).
from kpenvelope.hamiltonian import bulk_blocks

p = gan_rinke2008()
H0, _, _ = bulk_blocks(p, 0.0, 0.0)
E = np.sort(np.linalg.eigvalsh(H0))[::-1]   # descending; Kramers pairs
AB = (E[0] - E[2]) * 1e3
AC = (E[0] - E[4]) * 1e3
print(f"A-B splitting: {AB:.2f} meV  (published Rinke value 5.20)")
print(f"A-C splitting: {AC:.2f} meV  (published Rinke value 21.80)")
assert abs(AB - 5.20) < 0.01 and abs(AC - 21.80) < 0.01

# --- AlN/GaN/AlN quantum well --------------------------------------
vbo = 0.85                                  # valence-band offset (eV), user input
zw = np.linspace(0.0, 30.0, 601)
params, edge = layered_profile(
    zw, [(10.0, aln_rinke2008(), -vbo),
         (10.0, gan_rinke2008(), 0.0),
         (10.0, aln_rinke2008(), -vbo)])
Ew, envw = solve_heterostructure(zw, params, edge, n_states=4)
print(f"top well subbands (eV): {np.array2string(Ew, precision=4)}")

# confinement check: the ground envelope lives in the GaN layer
dz = zw[1] - zw[0]
w_in = (np.abs(envw[0][:, (zw >= 10.0) & (zw <= 20.0)]) ** 2).sum() * dz
print(f"ground-state weight inside the GaN well: {w_in:.3f}")
assert w_in > 0.9
# confinement pushes the top subband below the bulk edge (holes)
assert Ew[0] < E[0]
print("OK: lesson 2.2 complete")
