"""Module 2, Lesson 2.3 -- Subband dispersion, effective masses, spin
splitting, and intersubband optics (kpenvelope).

A hole mass is not one number: `local_mass` differentiates the actual
subband dispersion. Kramers pairs cannot split at k = 0 (checked), and
the v0.7 intersubband tools give the dipole matrix and oscillator
strengths, pinned here to the infinite-well closed forms and the
Thomas-Reiche-Kuhn sum rule.
"""
import numpy as np

from kpenvelope import (demo_single_band, dipole_matrix, local_mass,
                        oscillator_strengths, solve_subbands,
                        spin_splitting, subband_dispersion)

A = -2.0
p = demo_single_band(A=A)
L = 8.0
z = np.linspace(0.0, L, 401)

# --- dispersion and local mass -------------------------------------
kts = np.linspace(0.0, 0.6, 25)            # 1/nm, in-plane path
disp = subband_dispersion(p, z, kts, n_states=4)
k_mid, mass = local_mass(kts, disp)        # |m*|/m0 along the path
print(f"dispersion shape: {disp.shape}, local mass shape: {mass.shape}")
print(f"in-plane |mass| of the top subband at k~{k_mid[12]:.3f}/nm: "
      f"{mass[12, 0]:.4f} m0  (decoupled demo: exactly 1/|A| = 0.5)")
assert abs(mass[12, 0] - 1.0 / abs(A)) < 1e-6

# --- Kramers: no splitting at k = 0 --------------------------------
E0, _ = solve_subbands(p, z, kx=0.0, n_states=4)
print(f"spin splitting at k=0: {np.abs(spin_splitting(E0)).max():.2e} eV")
assert np.abs(spin_splitting(E0)).max() < 1e-12

# --- intersubband optics (v0.7) ------------------------------------
E, env = solve_subbands(p, z, n_states=60)
d = dipole_matrix(z, env)
f = oscillator_strengths(E, d, 1.0 / abs(A))    # m*/m0 = 0.5

# the demo set is SIX-FOLD degenerate: individual elements inside a
# multiplet are basis-dependent; the multiplet-summed quantities are
# the invariants, and those are what the closed forms pin.
z12 = np.sqrt((np.abs(d[0, 6:12]) ** 2).sum())
z12_exact = 16.0 * L / (9.0 * np.pi ** 2)
f12 = f[6:12].sum()
f12_exact = 256.0 / (27.0 * np.pi ** 2)
print(f"z12 (multiplet)  : {z12:.4f} nm | closed form {z12_exact:.4f} nm")
print(f"f12 (multiplet)  : {f12:.4f}    | closed form {f12_exact:.4f}")
print(f"TRK f-sum        : {f.sum():.4f}  (exact: 1)")
z13 = np.sqrt((np.abs(d[0, 12:18]) ** 2).sum())
print(f"parity-forbidden z13: {z13:.2e} nm  (~0)")
assert abs(z12 - z12_exact) / z12_exact < 0.01
assert abs(f12 - f12_exact) < 1e-3
assert 0.995 < f.sum() < 1.0005
assert z13 < 1e-9
print("OK: lesson 2.3 complete")
