"""Module 3, Lesson 3.1 -- The two-mode inversion: strain and carrier
density from Raman peak shifts (ramansep).

Two Raman modes with different strain lever arms and doping responses
form a linear, invertible probe of (strain, density). We use the cited
MoS2 A'1 + 2LA(M) coefficient set, verify the exact forward/inverse
round trip, and propagate measurement uncertainties.
"""
import numpy as np

import ramansep as rs

print(f"ramansep version: {rs.__version__}")

coeff = rs.mos2_a1_2la()          # cited set (provenance in .reference)
model = rs.SeparationModel(coeff)
print(f"modes: {coeff.mode1_name} + {coeff.mode2_name}")
print(f"lever-arm matrix K:\n{np.array(coeff.matrix())}")
print(f"condition number: {model.condition_number:.2f}")

# --- forward, then invert: the round trip is exact ------------------
rng = np.random.default_rng(0)
strain = rng.uniform(-0.2, 0.2, (4, 4))    # percent biaxial
density = rng.uniform(0.0, 1.0, (4, 4))    # 1e13 cm^-2 electrons
dw1, dw2 = model.forward(strain, density)
res = model.invert(dw1, dw2)
print(f"round-trip |strain error| max : "
      f"{np.abs(res.strain - strain).max():.2e} %")
print(f"round-trip |density error| max: "
      f"{np.abs(res.density - density).max():.2e} x1e13 cm^-2")
assert np.allclose(res.strain, strain, atol=1e-12)
assert np.allclose(res.density, density, atol=1e-12)

# --- uncertainty propagation ----------------------------------------
# 1-sigma peak-shift uncertainties of 0.15 cm^-1 on both modes
res_u = model.invert(dw1, dw2, sigma1=0.15, sigma2=0.15)
print(f"strain sigma  (uniform 0.15 cm^-1 shifts): "
      f"{res_u.strain_sigma.flat[0]:.4f} %")
print(f"density sigma                            : "
      f"{res_u.density_sigma.flat[0]:.4f} x1e13 cm^-2")
print(f"strain-density correlation               : "
      f"{res_u.correlation.flat[0]:+.3f}")
print("(correlations near +/-1 would mean the mode pair barely "
      "separates the two causes)")

# --- reproduce the source paper's edge-charge separation ------------
# A 0.5 cm^-1 A'1 redshift with the 2LA(M) unmoved is the paper's edge
# signature: pure charge, no strain.
res_edge = model.invert(np.array([-0.5]), np.array([0.0]))
print(f"A'1 -0.5 cm^-1, 2LA(M) 0 -> strain {res_edge.strain[0]:+.4f} %, "
      f"density {res_edge.density[0]:.3f} x1e13 cm^-2 "
      f"(= {res_edge.density[0] * 1e13:.2g} cm^-2)")
print("OK: lesson 3.1 complete")
