"""Module 3, Lesson 3.2 -- From raw spectra to strain/density values
(ramansep).

The fitting front end closes the gap between a measured spectrum and
the inversion: synthesize a noisy two-peak Raman spectrum with a KNOWN
(strain, density) state, fit both modes with `fit_two_modes`, and feed
the shifts straight into the inversion. The recovered state must agree
with the truth within the propagated uncertainty.
"""
import numpy as np

import ramansep as rs
from ramansep import lorentzian

rng = np.random.default_rng(1)
coeff = rs.mos2_a1_2la()
model = rs.SeparationModel(coeff)

# pristine reference frequencies of the two modes (cm^-1). For real
# data these come from YOUR pristine flake; here they are stand-ins.
REF1, REF2 = 404.0, 450.0

# ground truth at one map pixel
strain_true, density_true = 0.10, 0.60      # percent, 1e13 cm^-2
dw1, dw2 = model.forward(strain_true, density_true)
print(f"true shifts: dw1 = {float(dw1):+.3f}, dw2 = {float(dw2):+.3f} cm^-1")

# --- synthesize the measured spectrum -------------------------------
x = np.arange(380.0, 470.0, 0.35)           # spectrometer axis
y = (lorentzian(x, REF1 + float(dw1), 5.0, 900.0)
     + lorentzian(x, REF2 + float(dw2), 9.0, 420.0)
     + 60.0                                  # baseline
     + rng.normal(0.0, 6.0, x.size))         # shot/read noise

# --- fit both modes and invert --------------------------------------
dw1_fit, dw2_fit, s1, s2, fit1, fit2 = rs.fit_two_modes(
    x, y, window1=(390.0, 425.0), window2=(432.0, 468.0),
    ref1=REF1, ref2=REF2)
print(f"fitted shifts: dw1 = {dw1_fit:+.3f} +/- {s1:.3f}, "
      f"dw2 = {dw2_fit:+.3f} +/- {s2:.3f} cm^-1")
print(f"fit converged: {fit1.converged} / {fit2.converged}; "
      f"residual rms {fit1.residual_rms:.1f} / {fit2.residual_rms:.1f} counts")

res = model.invert(np.array([dw1_fit]), np.array([dw2_fit]),
                   sigma1=np.array([s1]), sigma2=np.array([s2]))
print(f"recovered strain : {res.strain[0]:+.4f} +/- "
      f"{res.strain_sigma[0]:.4f} %   (true {strain_true:+.3f})")
print(f"recovered density: {res.density[0]:+.4f} +/- "
      f"{res.density_sigma[0]:.4f} x1e13 cm^-2 (true {density_true:.3f})")

# agreement within 3 sigma of the propagated uncertainty
assert abs(res.strain[0] - strain_true) < 3 * res.strain_sigma[0]
assert abs(res.density[0] - density_true) < 3 * res.density_sigma[0]
print("OK: lesson 3.2 complete")
