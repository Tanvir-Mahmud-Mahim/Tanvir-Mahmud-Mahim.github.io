"""Module 3, Lesson 3.3 -- Beyond two modes, and calibrating your own
lever arms (ramansep).

Three or more modes make the inversion overdetermined: the redundancy
buys smaller uncertainties AND a per-pixel chi-square model check that
no exactly-determined inversion can offer. And when no literature
coefficient set fits your material, `calibrate_lever_arms` (v0.7)
fits the matrix from reference measurements you control.
"""
import numpy as np

import ramansep as rs

rng = np.random.default_rng(2)

# --- an overdetermined three-mode inversion ------------------------
# lever arms of three hypothetical modes (units as usual)
K = np.array([[-5.1, -2.2],
              [-20.9, 0.0],
              [-4.3, -0.33]])
mm = rs.MultiModeModel(K, mode_names=["A'1", "2LA(M)", "E'"])
strain, density = 0.15, 0.5
shifts_clean = K @ np.array([strain, density])
sig = np.array([0.10, 0.15, 0.10])
shifts = shifts_clean + rng.normal(0.0, sig)
res = mm.invert(shifts, sigmas=sig)
print(f"3-mode GLS: strain {float(res.strain):+.4f} +/- "
      f"{float(res.strain_sigma):.4f} %, density "
      f"{float(res.density):+.4f} +/- {float(res.density_sigma):.4f}")
print(f"model check: chi2 = {float(res.chi2_map):.3f} on {res.dof} dof, "
      f"p = {float(res.p_value):.3f}   (the two-cause model holds)")

# a pixel that VIOLATES the two-cause model (a third latent variable)
bad = shifts + np.array([0.0, 0.0, 1.2])
res_bad = mm.invert(bad, sigmas=sig)
print(f"violated pixel: p = {float(res_bad.p_value):.2e}  (flagged)")
assert float(res_bad.p_value) < 1e-3 < float(res.p_value)

# which mode pair is best? a computation, not a habit:
ranking = rs.compare_mode_sets(K, sigmas=sig,
                               mode_names=["A'1", "2LA(M)", "E'"])
best = ranking[0]
print(f"best 2-mode subset by D-optimality: {best['names']}")

# --- calibrate your own lever arms (v0.7) --------------------------
# reference states you control: a strain stage sweep (density 0)
# plus gated points (strain 0) -- together they span the plane.
eps_ref = np.array([0.00, 0.05, 0.10, 0.20, 0.00, 0.00, 0.00])
rho_ref = np.array([0.00, 0.00, 0.00, 0.00, 0.30, 0.60, 1.00])
K_true = np.array([[-5.1, -2.2], [-20.9, 0.0]])
meas = (np.column_stack([eps_ref, rho_ref]) @ K_true.T
        + rng.normal(0.0, 0.08, (7, 2)))
cal = rs.calibrate_lever_arms(eps_ref, rho_ref, meas, sigmas=0.08,
                              mode_names=["A'1", "2LA(M)"])
print("calibrated lever arms (true in brackets):")
for i in range(2):
    print(f"  mode {i + 1}: strain {cal.K[i, 0]:+.2f} +/- "
          f"{cal.K_sigma[i, 0]:.2f} [{K_true[i, 0]:+.1f}], doping "
          f"{cal.K[i, 1]:+.2f} +/- {cal.K_sigma[i, 1]:.2f} "
          f"[{K_true[i, 1]:+.1f}]")
print(f"chi2/dof: {(cal.chi2 / cal.chi2_dof).round(2)}  (near 1: model "
      f"and stated sigmas consistent)")
# each fitted arm within 3 sigma of the generating value
assert np.all(np.abs(cal.K - K_true) < 3.0 * cal.K_sigma + 1e-12)

# a strain-only sweep is refused: doping arms are not identifiable
try:
    rs.calibrate_lever_arms(eps_ref[:4], rho_ref[:4], meas[:4],
                            sigmas=0.08)
except ValueError as e:
    print(f"strain-only sweep refused: {str(e)[:60]}...")
print("OK: lesson 3.3 complete")
