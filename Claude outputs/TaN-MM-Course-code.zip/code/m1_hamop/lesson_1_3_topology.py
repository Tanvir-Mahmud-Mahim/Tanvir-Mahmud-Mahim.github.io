"""Module 1, Lesson 1.3 -- Topology: the Haldane model's Chern number
and the TKNN quantization of the Hall conductivity (hamop).

The Haldane model (Phys. Rev. Lett. 61, 2015 (1988)) is the canonical
Chern insulator. hamop computes the Chern number by the gauge-invariant
lattice field strength (Fukui-Hatsugai-Suzuki) and, completely
independently, the DC Hall conductivity from the Kubo tensor -- TKNN
says the two must agree: sigma_xy(0) = C e^2/h.
"""
import numpy as np

import hamop
from hamop import band_edges, chern_number, haldane, sigma_tensor

# --- topological phase ---------------------------------------------
m_top = haldane(t1=-1.0, t2=0.1, phi=np.pi / 2, m_ab=0.0)
C = chern_number(m_top, mesh=24, n_occ=1)
print(f"Haldane (phi=pi/2, m_AB=0)    : C = {C:+.6f}")
assert abs(C - round(C)) < 1e-9 and round(C) in (-1, 1)

# --- trivial phase: large sublattice mass --------------------------
m_triv = haldane(t1=-1.0, t2=0.1, phi=np.pi / 2, m_ab=1.0)
C0 = chern_number(m_triv, mesh=24, n_occ=1)
print(f"Haldane (m_AB = 1.0, trivial) : C = {C0:+.6f}")
assert abs(C0) < 1e-9

# --- TKNN: sigma_xy(0) = C e^2/h, computed via the Kubo tensor -----
vbm, cbm, gap = band_edges(m_top, mu=0.0, mesh=41)
mu = 0.5 * (vbm + cbm)                    # chemical potential in the gap
print(f"topological gap               : {gap:.4f} eV")
# sigma_tensor returns sigma_xy(omega) in units of e^2/(4 hbar);
# TKNN in those units reads sigma_xy(0) = 2 C / pi.
sig = sigma_tensor(m_top, np.array([0.0]), mu=mu, directions=(0, 1),
                   mesh=120, eta=1e-3, spin=1)
C_from_kubo = float(np.pi / 2.0 * np.real(sig[0]))
print(f"sigma_xy(0) route -> C        : {C_from_kubo:+.4f}")
print(f"lattice field strength -> C   : {C:+.4f}")
assert abs(C_from_kubo - C) < 1e-2        # two independent routes agree
print("OK: lesson 1.3 complete")
