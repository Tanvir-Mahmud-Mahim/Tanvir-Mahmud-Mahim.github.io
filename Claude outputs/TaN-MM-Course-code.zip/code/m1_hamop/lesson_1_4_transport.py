"""Module 1, Lesson 1.4 -- Quantum transport: Landauer transmission,
local density of states and bond currents (hamop).

A single-orbital chain with one impurity has the exact transmission
T(E) = (4t^2 - E^2) / ((4t^2 - E^2) + eps^2). We check hamop's NEGF
sweep against it, then use the v0.6 local-spectroscopy tools: the
device LDOS and the Paulsson-Brandbyge bond-current map, whose every
transverse cut must carry exactly T(E) (Kirchhoff for currents).
"""
import numpy as np

from hamop import (bond_currents, chain_lead_blocks, device_ldos,
                   transmission)

t = -1.0                                   # lead and device hopping (eV)
eps = 0.8                                  # impurity on-site energy (eV)
H00, H01 = chain_lead_blocks(t=t)          # semi-infinite lead blocks

# device: five single-site layers, impurity in the middle
layers_H = [np.array([[0.0]]), np.array([[0.0]]), np.array([[eps]]),
            np.array([[0.0]]), np.array([[0.0]])]
coup_H = [np.array([[t]])] * 4             # couplings between layers

# --- transmission against the closed form --------------------------
E_list = np.array([-1.5, -0.7, 0.0, 0.9, 1.6])
T = transmission(E_list, layers_H, coup_H, H00, H01)
T_exact = (4 * t**2 - E_list**2) / ((4 * t**2 - E_list**2) + eps**2)
print(" E (eV) |  T(E) hamop |  T(E) exact")
for E, a, b in zip(E_list, T, T_exact):
    print(f" {E:+5.2f}  |   {a:.6f}  |   {b:.6f}")
assert np.allclose(T, T_exact, atol=1e-4)  # finite-eta limited

# --- local density of states ----------------------------------------
E_probe = [0.0]
ldos = device_ldos(E_probe, layers_H, coup_H, H00, H01)[0]
print("site-resolved LDOS at E = 0 (1/eV):",
      np.array2string(ldos, precision=4))
print("(the impurity site carries less weight than its neighbors)")
assert ldos[2] < ldos[1]           # weight pushed off the impurity

# --- bond currents: every cut carries exactly T(E) ------------------
E0 = 0.5
J, offs = bond_currents(E0, layers_H, coup_H, H00, H01)
T0 = float(transmission(np.array([E0]), layers_H, coup_H, H00, H01)[0])
print(f"\nT({E0}) = {T0:.6f}; current through each inter-layer cut:")
for cut in range(4):                       # cut between layer `cut` and `cut+1`
    left = range(0, cut + 1)
    right = range(cut + 1, 5)
    Jcut = sum(J[i, j] for i in left for j in right)
    print(f"  cut {cut}-{cut + 1}: {Jcut:.6f}")
    assert abs(Jcut - T0) < 1e-4       # Kirchhoff: all cuts equal T (eta-limited)
# antisymmetry of the current map
assert np.allclose(J, -J.T, atol=1e-12)
print("OK: lesson 1.4 complete")
