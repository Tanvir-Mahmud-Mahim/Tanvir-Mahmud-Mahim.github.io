"""Module 1, Lesson 1.1 -- Your first tight-binding model (hamop).

Build the SSH chain from scratch, compute its band structure, gap and
density of states, and check the gap against the closed form 2|t1 - t2|.

Requires: pip install hamop   (this course was validated on hamop 0.6.0)
"""
import numpy as np

import hamop
from hamop import TightBindingModel, band_edges, bands, dos

print(f"hamop version: {hamop.__version__}")

# --- build the SSH chain by hand -----------------------------------
# Two sites per cell (positions in Angstrom), one orbital each,
# 1D lattice with a 2.0 A cell. Each directed hopping block is added
# once; the Hermitian partner is implied.
t1, t2 = -1.0, -0.6                      # eV: intra- and inter-cell bonds
m = TightBindingModel(positions=[[0.0], [0.7]], norb=1, cell=[[2.0]])
m.add_hop(0, 1, (0,), [[t1]])            # bond inside the cell
m.add_hop(1, 0, (1,), [[t2]])            # bond to the next cell

# --- band structure along the 1D Brillouin zone --------------------
kpts = np.linspace(0.0, np.pi / 2.0, 101)[:, None]   # k in 1/A; BZ edge pi/a
E = bands(m, kpts)                                    # (nk, 2)
print(f"band shape: {E.shape}")
print(f"valence band top    : {E[:, 0].max():+.6f} eV")
print(f"conduction band min : {E[:, 1].min():+.6f} eV")

# --- the gap, against the closed form ------------------------------
vbm, cbm, gap = band_edges(m, mu=0.0, mesh=2001)
print(f"band_edges gap      : {gap:.6f} eV")
print(f"closed form 2|t1-t2|: {2 * abs(t1 - t2):.6f} eV")
assert abs(gap - 2 * abs(t1 - t2)) < 1e-4   # k-grid resolution limited

# --- density of states ---------------------------------------------
w = np.linspace(-2.2, 2.2, 221)
rho = dos(m, w, mesh=4001, eta=0.02)
trapz = getattr(np, "trapezoid", getattr(np, "trapz", None))  # numpy 1/2 compat
print(f"DOS integrates to   : {trapz(rho, w):.4f}  (2 orbitals/cell)")
print(f"DOS inside the gap  : {rho[np.abs(w) < 0.3].max():.2e}  (~0)")

# --- the same model from the built-in constructor ------------------
m2 = hamop.ssh(t1=t1, t2=t2)
E2 = bands(m2, kpts)
print(f"hand-built == built-in ssh(): "
      f"{np.allclose(E, E2, atol=1e-12)}")
print("OK: lesson 1.1 complete")
