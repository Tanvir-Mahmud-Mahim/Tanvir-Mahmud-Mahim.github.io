"""Module 1, Lesson 1.2 -- Graphene: Dirac bands and the universal
optical conductivity (hamop).

The interband conductivity of graphene is universal: sigma = e^2/(4 hbar),
independent of the hopping and the lattice constant (Kuzmenko et al.,
Phys. Rev. Lett. 100, 117401 (2008)). hamop reports sheet conductivity
in exactly those units, so the plateau must come out at ~1. This lesson
also verifies the Dirac closure at K and the bandwidth +/-3|t| at Gamma.
"""
import numpy as np

import hamop
from hamop import bands, graphene, sigma_optical

t, a = -2.7, 2.46                        # eV, Angstrom
g = graphene(t=t, a=a)

# --- exact band anchors --------------------------------------------
# K point of the hexagonal lattice: |K| = 4 pi / (3 a)
K = np.array([[4 * np.pi / (3 * a), 0.0]])
Gamma = np.array([[0.0, 0.0]])
EK = bands(g, K)[0]
EG = bands(g, Gamma)[0]
print(f"gap at K      : {EK[1] - EK[0]:.3e} eV   (Dirac point: 0)")
print(f"bands at Gamma: {EG[0]:+.4f}, {EG[1]:+.4f} eV  (exact +/-3|t| "
      f"= +/-{3 * abs(t):.1f})")
assert abs(EK[1] - EK[0]) < 1e-10
assert np.allclose(EG, [-3 * abs(t), 3 * abs(t)], atol=1e-10)

# --- universal interband plateau -----------------------------------
omega = np.linspace(0.8, 1.8, 6)          # eV, well inside the plateau
sig = sigma_optical(g, omega, mu=0.0, mesh=150, eta=0.12)
print("omega (eV) | sigma / (e^2 / 4 hbar)")
for w, s in zip(omega, sig):
    print(f"   {w:5.2f}   |   {s:.3f}")
print(f"plateau mean: {sig.mean():.3f}  (universal value: 1)")
assert abs(sig.mean() - 1.0) < 0.05
print("OK: lesson 1.2 complete")
