"""Module 8, Lesson 8.1 -- Exact thin-film optics and adjoint inverse
design (fabtwin).

The characteristic-matrix solver is pinned to closed forms (here: the
quarter-wave antireflection transform and R + T = 1), the hand-derived
adjoint gradient is checked against finite differences, and the
probe-seeded design engine recovers the analytic AR optimum.
"""
import numpy as np

import fabtwin as ft

print(f"fabtwin version: {ft.__version__}")

# --- closed-form anchors -------------------------------------------
lam0 = 0.55                                # um
ns = 1.52                                  # glass substrate
# quarter-wave AR coating: n = sqrt(ns), t = lam0 / (4 n) -> R = 0
n_ar = np.sqrt(ns)
t_ar = lam0 / (4.0 * n_ar)
lam = np.array([lam0])
T = ft.transmittance(lam, np.array([t_ar]), np.array([[n_ar]]), 1.0, ns)
R = ft.reflectance(lam, np.array([t_ar]), np.array([[n_ar]]), 1.0, ns)
R0, T0 = float(R[0]), float(T[0])
print(f"quarter-wave AR at {lam0} um: R = {R0:.2e} (exact 0), "
      f"R + T = {R0 + T0:.12f}")
assert R0 < 1e-12 and abs(R0 + T0 - 1.0) < 1e-12

# energy conservation on a random lossless stack
rng = np.random.default_rng(0)
tr = rng.uniform(0.03, 0.10, 6)
nr = rng.uniform(1.5, 2.3, 6)
lam_g = np.linspace(0.45, 0.65, 21)
Tr = ft.transmittance(lam_g, tr, nr[:, None] * np.ones((1, 21)), 1.0, ns)
Rr = ft.reflectance(lam_g, tr, nr[:, None] * np.ones((1, 21)), 1.0, ns)
print(f"random 6-layer stack: max |R + T - 1| = "
      f"{np.abs(Rr + Tr - 1).max():.2e}")
assert np.abs(Rr + Tr - 1).max() < 1e-12

# --- the hand adjoint vs central finite differences ----------------
S = np.ones((1, lam_g.size))               # dispersionless for the check
w, c0 = ft.bandpass_weights(lam_g, 0.53, 0.57, 0.02)
t0 = rng.uniform(0.04, 0.09, 4)
n0 = rng.uniform(1.6, 2.2, 4)
Sfull = np.ones((4, lam_g.size))
J0, gt, gn = ft.merit_and_grad(lam_g, t0, n0, Sfull, w, c0, n_sub=ns)
h = 1e-6
fd = np.empty(4)
for i in range(4):
    tp, tm = t0.copy(), t0.copy()
    tp[i] += h
    tm[i] -= h
    Jp = ft.merit_and_grad(lam_g, tp, n0, Sfull, w, c0, n_sub=ns)[0]
    Jm = ft.merit_and_grad(lam_g, tm, n0, Sfull, w, c0, n_sub=ns)[0]
    fd[i] = (Jp - Jm) / (2 * h)
err = np.abs(gt - fd).max() / np.abs(fd).max()
print(f"adjoint dJ/dt vs finite differences: max rel err {err:.2e}")
assert err < 1e-6

# --- inverse design recovers the analytic AR optimum ----------------
box = ft.DesignBox(1, 0.02, 0.20, 1.05, 2.4)
# merit = T(lam0): weights [1], constant 0 -- maximize transmission
t_opt, n_opt, J_opt, hist = ft.inverse_design(
    np.array([lam0]), np.ones((1, 1)), np.array([1.0]), 0.0, box,
    n_sub=ns, seed=1)
to, no = float(t_opt[0]), float(n_opt[0])
print(f"designed AR layer: t = {to:.6f} um (analytic {t_ar:.6f}), "
      f"n = {no:.6f} (analytic {n_ar:.6f})")
assert abs(to - t_ar) < 1e-3 and abs(no - n_ar) < 1e-3
print("OK: lesson 8.1 complete")
