"""Module 8, Lesson 8.3 -- Bring your own fabrication data (fabtwin
v0.2).

The twins never see a simulator: they consume (recipe, outcome)
traces, which is exactly what a monitored deposition tool logs. This
lesson runs the complete real-data workflow: traces to CSV and back
(exact round trip), structural validation with plausibility flags,
a held-out twin-fidelity report, and the honest scope statement that
goes with it.
"""
import os
import tempfile

import numpy as np

import fabtwin as ft

rng = np.random.default_rng(7)

# --- a "fab log": traces in the documented CSV contract -------------
box = ft.DesignBox(8, 0.020, 0.120, 1.6, 2.4)
recipes = box.sample(rng, 40)
rt, rn, ftd, fnd = ft.PAPER_PROCESS.trace_dataset(*recipes, 2, rng)

path = os.path.join(tempfile.mkdtemp(), "fab_traces.csv")
ft.save_traces_csv(path, rt, rn, ftd, fnd)
rt2, rn2, ft2, fn2 = ft.load_traces_csv(path)
print(f"CSV round trip exact: "
      f"{np.array_equal(rt, rt2) and np.array_equal(fn2, fnd)}")
assert np.array_equal(rt, rt2) and np.array_equal(ftd, ft2)

# --- validation: structure raises, plausibility is reported ---------
rep = ft.validate_traces(rt2, rn2, ft2, fn2)
print(f"validated: {rep['n_runs']} runs x {rep['n_layers']} layers, "
      f"{len(rep['flags'])} plausibility flags")
mixed = ft2.copy()
mixed[3, 2] *= 1000.0                      # a nm-vs-um unit mix-up
rep2 = ft.validate_traces(rt2, rn2, mixed, fn2)
print(f"after injecting a unit mix-up: {len(rep2['flags'])} flag(s), "
      f"first = (run {rep2['flags'][0][0]}, layer {rep2['flags'][0][1]}, "
      f"{rep2['flags'][0][2]})")
assert len(rep2["flags"]) >= 1             # flagged, not silently dropped

# --- held-out twin fidelity -----------------------------------------
lam = np.linspace(0.45, 0.65, 41)
S = ft.dispersion_shape(lam, 0.550)
nsub = ft.SIO2_MALITSON1965.n(lam)
w, c0 = ft.notch_weights(lam, 0.532, 0.015, 0.030)

x = ft.errors_from_traces(rt2, rn2, ft2, fn2)
x_fit, x_hold = x[::2], x[1::2]            # fit on half, score on rest
twin = ft.GaussianTwin(x_fit)
designs = [(rt2[0], rn2[0]), (rt2[5], rn2[5])]
report = ft.twin_fidelity_report(
    twin.sample_errors(np.random.default_rng(1), 400), x_hold,
    designs, lam, S, w, c0, n_sub=nsub, alpha=0.1)
print("held-out fidelity report (paper Table I(A) statistic types):")
print(f"  moments : d_mean {report['moments']['d_mean']:.4f}, "
      f"d_corr {report['moments']['d_corr']:.3f}")
print(f"  induced : |dP10| {report['induced']['d_P']:.4f}, "
      f"|dCVaR| {report['induced']['d_CVaR']:.4f}, "
      f"W1 {report['induced']['W1']:.4f}")

# a deliberately broken twin must score strictly worse
broken = ft.GaussianTwin(x_fit + 0.05)
rep_b = ft.twin_fidelity_report(
    broken.sample_errors(np.random.default_rng(1), 400), x_hold,
    designs, lam, S, w, c0, n_sub=nsub, alpha=0.1)
print(f"  broken twin W1: {rep_b['induced']['W1']:.4f}  "
      f"(> fitted twin's {report['induced']['W1']:.4f})")
assert rep_b["induced"]["W1"] > report["induced"]["W1"]
assert rep_b["moments"]["d_mean"] > report["moments"]["d_mean"]

print("\nHONEST SCOPE: a held-out split certifies the twin against your "
      "fab's RECORDED behavior; it cannot certify error patterns the "
      "tool has never logged, and in production the twin needs periodic "
      "retraining as the tool drifts.")
print("OK: lesson 8.3 complete")
