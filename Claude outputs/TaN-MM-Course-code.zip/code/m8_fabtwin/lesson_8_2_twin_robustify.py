"""Module 8, Lesson 8.2 -- Process twins and pathwise CVaR
robustification (fabtwin).

The six-mechanism virtual deposition process generates historical
(recipe, outcome) traces; a Gaussian twin learns the error
distribution; and `robustify` ascends the yield-deciding lower-tail
statistic (CVaR) pathwise through the twin and the exact physics at
once. The robustified design must beat the nominal design in the tail
it optimizes -- under the TRUE process, which the twin never saw.
"""
import numpy as np

import fabtwin as ft

rng = np.random.default_rng(0)

# --- platform: 8-layer SiNx notch filter on silica ------------------
lam = np.linspace(0.45, 0.65, 41)
S = ft.dispersion_shape(lam, 0.550)          # Si3N4 shape (Luke 2015)
nsub = ft.SIO2_MALITSON1965.n(lam)           # substrate (Malitson 1965)
w, c0 = ft.notch_weights(lam, 0.532, 0.015, 0.030)
box = ft.DesignBox(8, 0.020, 0.120, 1.6, 2.4)

# nominal design
t0, n0, J0, _ = ft.inverse_design(lam, S, w, c0, box, n_sub=nsub,
                                  n_iter=30, seed=0)
print(f"nominal design merit: {J0:.4f}")

# --- historical traces and the Gaussian twin ------------------------
recipes = box.sample(rng, 150)
rt, rn, ftd, fnd = ft.PAPER_PROCESS.trace_dataset(*recipes, 2, rng)
x = ft.errors_from_traces(rt, rn, ftd, fnd)
print(f"trace dataset: {rt.shape[0]} runs -> error vectors {x.shape}")
twin = ft.GaussianTwin(x)

# --- robustify: CVaR ascent through twin + physics ------------------
alpha = 0.10
t_r, n_r, hist = ft.robustify(lam, t0, n0, S, w, c0, twin, box,
                              alpha=alpha, K=64, steps=40, lr=2e-3,
                              seed=1, n_sub=nsub)
obj = [h[1] for h in hist]                   # (step, objective) pairs
print(f"CVaR objective: start {obj[0]:.4f} -> end {obj[-1]:.4f}")
assert obj[-1] >= obj[0] - 1e-9              # ascent does not degrade

# --- score BOTH designs under the true process ----------------------
def sampler(a, b, K):
    return ft.PAPER_PROCESS.ensemble(a, b, K, rng)

rep_nom = ft.evaluate_under_process(sampler, t0, n0, lam, S, w, c0,
                                    K=3000, n_sub=nsub, alpha=alpha)
rep_rob = ft.evaluate_under_process(sampler, t_r, n_r, lam, S, w, c0,
                                    K=3000, n_sub=nsub, alpha=alpha)
print("                nominal   robustified")
for key in ("mean", "CVaR"):
    print(f"  {key:6s}     {rep_nom[key]:.4f}    {rep_rob[key]:.4f}")
print(f"tail (CVaR_{alpha}) improvement under the TRUE process: "
      f"{rep_rob['CVaR'] - rep_nom['CVaR']:+.4f}")
assert rep_rob["CVaR"] > rep_nom["CVaR"]     # the point of the loop
print("OK: lesson 8.2 complete")
