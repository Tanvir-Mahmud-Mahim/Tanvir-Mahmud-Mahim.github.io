"""Module 7, Lesson 7.2 -- The photonic molecule and honest detection
budgets (sqzcomb).

A single Kerr ring cannot be critically coupled without paying the
3 dB extraction penalty; coupling it to an auxiliary "extraction ring"
(a photonic molecule) routes the squeezing out. The detection module
then applies the loss and dark-noise model every real receiver adds --
and inverts it into a loss budget.
"""
import numpy as np

from sqzcomb import (detected_squeezing_db, molecule_threshold,
                     output_variance_ports, photonic_molecule,
                     required_efficiency_db, squeezing_db)

# --- molecule: threshold and detected squeezing ---------------------
J, gamma = np.sqrt(3.0), 1.0                # ring-ring coupling, aux loss
thr = molecule_threshold(J, gamma)
print(f"molecule threshold at J^2/gamma = {J ** 2 / gamma:.1f}: "
      f"mu_thr = {thr:.4f}   (single ring: 1)")

mu = 0.98 * thr                              # pump at 98% of threshold
M, gams = photonic_molecule(mu, J, gamma=gamma)
# read the squeezing through the AUXILIARY ring's bus (port mode 1);
# the -iJ hop rotates the squeezed quadrature a quarter turn, so the
# aux port squeezes at phi = 0 where the Kerr ring squeezes at pi/2.
v_aux = output_variance_ports(M, gams, eta=1.0, port_mode=1,
                              omega=0.0, phi=0.0)
print(f"detected variance through the auxiliary port: {v_aux:.5f} "
      f"-> {squeezing_db(v_aux):.2f} dB")
# the critically coupled single ring saturates at 3.01 dB; the
# molecule's dedicated extraction ring goes past that wall
assert squeezing_db(v_aux) < -4.0

# --- what the photodiodes actually report ---------------------------
print("\nreceiver chain (loss eta, dark clearance):")
for eta in (1.0, 0.9, 0.7, 0.5):
    db = detected_squeezing_db(v_aux, efficiency=eta)
    print(f"  eta = {eta:.1f}: {db:+.2f} dB")
# loss can only degrade squeezing, monotonically
dbs = [detected_squeezing_db(v_aux, efficiency=e)
       for e in (1.0, 0.9, 0.7, 0.5)]
assert all(a < b for a, b in zip(dbs, dbs[1:]))

# --- invert the model: the loss budget ------------------------------
target_db, source_db = -3.0, squeezing_db(v_aux)
eta_min = required_efficiency_db(target_db, source_db)
print(f"\nto deliver {target_db} dB from a {source_db:.2f} dB source, "
      f"total efficiency must exceed {eta_min:.3f}")
db_at_min = detected_squeezing_db(v_aux, efficiency=eta_min)
print(f"check: at eta = {eta_min:.3f} the detected level is "
      f"{db_at_min:.3f} dB")
assert abs(db_at_min - target_db) < 1e-9
print("OK: lesson 7.2 complete")
