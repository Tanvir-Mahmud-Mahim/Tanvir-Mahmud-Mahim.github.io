"""Module 7, Lesson 7.3 -- Entanglement, intracavity and detected
(sqzcomb v0.8).

The two-mode squeezed vacuum's log-negativity is E_N = 2r exactly --
the intracavity anchor. The v0.8 output-field toolbox then computes
what a detector SEES: the entanglement of the propagating output
modes of a nondegenerate parametric process, with the twin-beam
closed form E_N = -ln(2 V_EPR_min) as its anchor and detection loss
that can only degrade it.
"""
import numpy as np

from sqzcomb import (logarithmic_negativity, output_covariance_xxpp,
                     output_entanglement, output_entanglement_spectrum,
                     ppt_symplectic_eigenvalue)


def tmsv_cov(r, hbar=2.0):
    """Two-mode squeezed vacuum covariance, xxpp ordering."""
    c, s = np.cosh(2 * r), np.sinh(2 * r)
    unit = hbar / 2.0
    sig = unit * np.array([[c, s, 0, 0],
                           [s, c, 0, 0],
                           [0, 0, c, -s],
                           [0, 0, -s, c]])
    return sig


# --- intracavity anchor: E_N(TMSV) = 2r exactly ---------------------
for r in (0.3, 0.8, 1.5):
    EN = logarithmic_negativity(tmsv_cov(r))
    print(f"TMSV r = {r}: E_N = {EN:.6f}  (exact 2r = {2 * r})")
    assert abs(EN - 2 * r) < 1e-12

# --- output fields of a nondegenerate parametric process ------------
# modes (a1, a2) coupled by a pump: da1 = -a1 + mu a2*, symmetric.
mu, eta = 0.6, 0.8


def twin_drift(mu):
    A = -np.eye(2, dtype=complex)
    B = np.array([[0.0, mu], [mu, 0.0]], dtype=complex)
    return np.block([[A, B], [np.conj(B), np.conj(A)]])


M = twin_drift(mu)
sig_out = output_covariance_xxpp(M, eta, 0.0, n_modes=2)
print(f"\noutput covariance shape: {sig_out.shape} (xxpp)")
EN_out = output_entanglement(M, eta, 0.0, 0, 1, 2)
# twin-beam closed form: E_N = -ln(2 V_EPR_min), from the same cov
x1, x2 = sig_out[0, 0], sig_out[1, 1]
x12 = sig_out[0, 1]
p1, p2, p12 = sig_out[2, 2], sig_out[3, 3], sig_out[2, 3]
V_minus = 0.5 * (x1 + x2 - 2 * x12)        # Var[(x1 - x2)/sqrt(2)]
V_plus = 0.5 * (p1 + p2 + 2 * p12)         # Var[(p1 + p2)/sqrt(2)]
V_epr = min(V_minus, V_plus)
print(f"detected E_N at carrier: {EN_out:.6f}")
print(f"-ln(2 V_EPR_min)       : {-np.log(2 * V_epr):.6f}")
assert abs(EN_out - (-np.log(2 * V_epr))) < 1e-9

# --- the entanglement spectrum, and loss monotonicity ---------------
omegas = np.array([0.0, 0.5, 1.0, 2.0, 4.0])
spec = output_entanglement_spectrum(M, eta, omegas, 0, 1, 2)
print("E_N(Omega):", np.round(spec, 4))
assert np.all(np.diff(spec) <= 1e-12)       # decays away from carrier
spec_lossy = output_entanglement_spectrum(M, eta, omegas, 0, 1, 2,
                                          detection_efficiency=0.6)
print("with 60% detection:", np.round(spec_lossy, 4))
assert np.all(spec_lossy <= spec + 1e-12)   # loss never creates E_N

# PPT sanity: an unpumped (vacuum) output is separable
EN_vac = output_entanglement(twin_drift(0.0), eta, 0.0, 0, 1, 2)
print(f"unpumped output E_N: {EN_vac:.2e}  (separable: 0)")
assert EN_vac < 1e-12
print("OK: lesson 7.3 complete")
