"""Module 7, Lesson 7.1 -- Kerr-comb steady states and squeezing
spectra (sqzcomb).

The Lugiato-Lefever equation's flat steady states obey an exact cubic;
the linearized fluctuations around any steady state give detected
squeezing spectra through input-output theory. The degenerate
parametric oscillator is the closed-form anchor -- including the
famous 3 dB extraction limit at critical coupling.
"""
import numpy as np

import sqzcomb
from sqzcomb import (fluctuation_matrix, homogeneous_steady_states,
                     output_quadrature_variance, single_mode_parametric,
                     squeezing_db)

print(f"sqzcomb version: {sqzcomb.__version__}")

# --- LLE flat states satisfy the exact cubic ------------------------
F, alpha = 1.1, 0.5                         # pump amplitude, detuning
rhos = homogeneous_steady_states(F, alpha)  # |psi|^2 roots
print(f"flat-state intensities for F={F}, alpha={alpha}: "
      f"{np.round(rhos, 6)}")
for rho in rhos:
    resid = rho * (1.0 + (alpha - rho) ** 2) - F ** 2
    assert abs(resid) < 1e-9                # the exact cubic
print("every root satisfies rho[1 + (alpha - rho)^2] = F^2 exactly")

# --- DPO closed form: S(Omega) = 1 - 4 eta mu / ((1+mu)^2 + Omega^2)
mu, eta = 0.9, 1.0
M = single_mode_parametric(mu)
print("\nDPO squeezing spectrum (phi = pi/2 quadrature, eta = 1):")
print(" Omega | package variance | closed form")
for om in (0.0, 0.7, 2.5):
    v = output_quadrature_variance(M, eta, om, mode_index=0, n_modes=1,
                                   phi=np.pi / 2)
    v_exact = 0.5 * (1 - 4 * eta * mu / ((1 + mu) ** 2 + om ** 2))
    print(f"  {om:3.1f}  |     {v:.6f}     |  {v_exact:.6f}")
    assert abs(v - v_exact) < 1e-10

# --- the 3 dB extraction limit at critical coupling -----------------
M99 = single_mode_parametric(0.9999)
v_crit = output_quadrature_variance(M99, 0.5, 0.0, 0, 1, phi=np.pi / 2)
print(f"\ncritical coupling (eta = 1/2), mu -> 1: "
      f"{squeezing_db(v_crit):.3f} dB  (limit: -3.01 dB)")
assert -3.011 < squeezing_db(v_crit) < -2.99

# --- an LLE comb state's fluctuation matrix -------------------------
rho0 = float(rhos[0])
psi_s = np.sqrt(rho0) * np.ones(8, dtype=complex)
Mc, modes = fluctuation_matrix(psi_s, alpha, dispersion=(0.0, 0.0, 0.15))
print(f"comb fluctuation matrix: {Mc.shape} over modes {modes}")
stable = np.max(np.linalg.eigvals(Mc).real) < 0.0
print(f"flat lower-branch state stable: {stable}")
assert stable
print("OK: lesson 7.1 complete")
