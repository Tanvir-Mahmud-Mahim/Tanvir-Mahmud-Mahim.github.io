"""Module 4, Lesson 4.2 -- Three honest answers to "what is g2(0)?"
(sparq-triage).

The same twin-generated histogram is analyzed three ways: the
bootstrap pipeline (shot noise through every analysis step), the Wilks
profile likelihood (model-based, exact Poisson), and the v0.5 exact
Bayesian posterior of the raw central-window ratio (closed-form
beta-prime, no sampling). Each answers a slightly different question;
all three should bracket the truth here.
"""
import numpy as np

import sparq

cfg = sparq.HBTConfig()
site = sparq.EmitterSite(dict(tau1=15.0, tau2=250.0, a=0.4, rho=0.95,
                              rate_kcps=150.0, blinking=False),
                         n_emitters=1)
print(f"true model g2(0) (background-limited): {site.g2_0:.4f}")

T_s = 60.0
rng = np.random.default_rng(3)

# Raw correlator data arrive on the instrument's own grid -- wider
# than the analysis window and offset (nobody centers hardware delays
# at exactly zero). analyze_histogram locates the dip and re-bins.
cfg_raw = sparq.HBTConfig(tau_max=90.0, n_bins=360, sigma_irf=0.35)
mu_raw = sparq.expected_histogram(site, T_s, cfg_raw)
delay_raw = cfg_raw.bin_centers + 7.0            # 7 ns hardware offset
counts_raw = rng.poisson(mu_raw).astype(float)

# --- route 1: the bootstrap pipeline --------------------------------
res = sparq.analyze_histogram(delay_raw, counts_raw, T_s=T_s,
                              n_bootstrap=100, seed=0)
print(f"[bootstrap]  dip located at {res['center']:+.2f} ns "
      f"(true offset +7.00)")
print(f"[bootstrap]  g2(0) = {res['g2_0']:.3f}  "
      f"68% CI ({res['g2_0_low']:.3f}, {res['g2_0_high']:.3f})  "
      f"single-emitter confident: {res['single_emitter_confident']}")

# --- route 2: Wilks profile likelihood ------------------------------
# re-bin the raw data onto the standard analysis grid, dip-centered
from sparq.datasets import rebin_real, robust_flat_rate
h, center = rebin_real(delay_raw, counts_raw, cfg)
h = h.astype(float)
r_hat = robust_flat_rate(h, cfg, T_s)
prof = sparq.profile_likelihood_ci(h, T_s, r_hat, cfg, level=0.95)
print(f"[profile]    g2(0) = {prof['g2_hat']:.3f}  "
      f"95% CI ({prof['lo']:.3f}, {prof['hi']:.3f})")

# --- route 3: exact Bayesian posterior (v0.5) -----------------------
post = sparq.bayesian_g2(h, cfg)                    # Jeffreys prior
lo, hi = post.credible_interval(0.95)
print(f"[Bayes]      raw window g2 median = {post.median():.3f}  "
      f"95% credible ({lo:.3f}, {hi:.3f})")
print(f"[Bayes]      P(g2 < 0.5 | data) = {post.prob_below(0.5):.6f}")

# NOTE the estimand difference, stated honestly: routes 1-2 estimate
# the model's g2(0); route 3 estimates the RAW 1-ns window average,
# which sits on top of the dip and upper-bounds g2(0).

# --- background correction ------------------------------------------
# the twin included rho = 0.95; correct the raw Bayes median for it
corr = sparq.background_corrected_g2(post.median(), rho=0.95)
print(f"background-corrected raw g2: {corr['g2_corrected']:.3f}")

assert res['g2_0'] < 0.5 and prof['hi'] < 0.5
assert post.prob_below(0.5) > 0.99
print("OK: lesson 4.2 complete")
