"""Module 4, Lesson 4.3 -- Sequential certification: stop acquiring
the moment the evidence suffices (sparq-triage).

Wald's SPRT on accumulating HBT histograms: after every data
increment the exact Poisson log-likelihood ratio between the
single-emitter and pair hypotheses is updated, and acquisition stops
at the error-rate thresholds. Bright single emitters certify in a
fraction of the fixed dwell a conventional protocol would spend.
"""
import numpy as np

import sparq

cfg = sparq.HBTConfig()
params = dict(tau1=15.0, tau2=250.0, a=0.3, rho=0.95,
              rate_kcps=250.0, blinking=False)
site1 = sparq.EmitterSite(params, 1)      # accept hypothesis
site2 = sparq.EmitterSite(params, 2)      # reject hypothesis
print(f"hypotheses: g2(0) = {site1.g2_0:.3f} (single) vs "
      f"{site2.g2_0:.3f} (pair)")

rng = np.random.default_rng(4)
dt = 0.05                                  # seconds per increment


def run_sprt(true_site, seed):
    rng = np.random.default_rng(seed)
    cert = sparq.SPRTCertifier(site1, site2, cfg=cfg,
                               alpha=0.05, beta=0.05)
    t = 0.0
    while True:
        counts = rng.poisson(sparq.expected_histogram(true_site, dt, cfg))
        verdict = cert.update(counts, dt)
        t += dt
        if verdict != "continue" or t > 30.0:
            return verdict, t


# --- certify a true single emitter ---------------------------------
times1 = []
for s in range(20):
    v, t = run_sprt(site1, seed=100 + s)
    assert v in ("accept", "reject")
    times1.append((v, t))
acc = sum(1 for v, _ in times1 if v == "accept")
mean_t = np.mean([t for _, t in times1])
print(f"true single emitter, 20 runs: {acc}/20 accepted, "
      f"mean decision time {mean_t:.2f} s")

# --- and a true pair -----------------------------------------------
times2 = []
for s in range(20):
    v, t = run_sprt(site2, seed=300 + s)
    times2.append((v, t))
rej = sum(1 for v, _ in times2 if v == "reject")
mean_t2 = np.mean([t for _, t in times2])
print(f"true pair,           20 runs: {rej}/20 rejected, "
      f"mean decision time {mean_t2:.2f} s")

print(f"(a fixed-dwell protocol would spend ~30 s per site; the SPRT "
      f"decided in well under a second here)")
assert acc >= 18 and rej >= 18             # ~nominal 5% error rates
assert mean_t < 5.0 and mean_t2 < 5.0
print("OK: lesson 4.3 complete")
