"""Module 4, Lesson 4.1 -- The HBT twin and its exact master-equation
reference (sparq-triage).

The analytic two-exponential g2 law (antibunching dip + metastable
bunching shoulder) is cross-checked against the numerically exact
three-level master equation, and the histogram twin's expected counts
follow the exact Poisson statistics of an HBT acquisition.
"""
import numpy as np

import sparq

print(f"sparq-triage version: {sparq.__version__}")

# --- analytic g2 vs the exact master equation ----------------------
# The nominal (tau1, tau2, a) map to CTMC rates; the EXACT
# two-exponential parameters of that CTMC come back slightly
# renormalized from the eigen-decomposition (`effective_params`).
# With those, the analytic law equals the exact master equation to
# machine precision -- the package's core cross-validation.
tau1, tau2, a = 15.0, 250.0, 0.4          # ns, ns, bunching amplitude
rates = sparq.rates_from_site(tau1, tau2, a)
t1e, t2e, ae = sparq.effective_params(*rates)
print(f"nominal   (tau1, tau2, a): ({tau1:.2f}, {tau2:.1f}, {a:.3f})")
print(f"effective (tau1, tau2, a): ({t1e:.2f}, {t2e:.1f}, {ae:.3f})")
tau = np.array([0.0, 2.0, 10.0, 40.0, 150.0, 600.0])
g2_analytic = sparq.g2_three_level(tau, t1e, t2e, ae)
g2_master = sparq.g2_exact(tau, *rates)
print(" tau (ns) | analytic g2 | master-equation g2")
for t, ga, gm in zip(tau, g2_analytic, g2_master):
    print(f"  {t:6.1f}  |   {ga:.6f}  |   {gm:.6f}")
assert np.abs(g2_analytic - g2_master).max() < 1e-10
print("two independent code paths agree to machine precision")

# --- single- vs multi-emitter zero-delay values --------------------
for n in (1, 2, 3):
    g0 = sparq.g2_zero(tau1, tau2, a, n_emitters=n, rho=1.0)
    print(f"n_emitters = {n}: g2(0) = {g0:.4f}   "
          f"(the n-emitter floor 1 - 1/n = {1 - 1 / n:.4f})")

# --- the histogram twin --------------------------------------------
cfg = sparq.HBTConfig()                   # 121 bins, +/-60.5 ns, 1 ns bins
site = sparq.EmitterSite(dict(tau1=tau1, tau2=tau2, a=a, rho=0.95,
                              rate_kcps=150.0, blinking=False),
                         n_emitters=1)
print(f"site g2(0) (with rho=0.95 background): {site.g2_0:.4f}")
T_s = 30.0                                # seconds of acquisition
mu = sparq.expected_histogram(site, T_s, cfg)
rng = np.random.default_rng(0)
h = rng.poisson(mu)
mid = cfg.n_bins // 2
far = np.abs(cfg.bin_centers) >= 0.65 * cfg.tau_max
print(f"expected counts: center bin {mu[mid]:.1f}, far-delay mean "
      f"{mu[far].mean():.1f}")
print(f"sampled  counts: center bin {h[mid]}, far-delay mean "
      f"{h[far].mean():.1f}")
print(f"raw dip ratio (sampled): {h[mid] / h[far].mean():.3f}")
assert mu[mid] < 0.6 * mu[far].mean()     # a real dip
print("OK: lesson 4.1 complete")
