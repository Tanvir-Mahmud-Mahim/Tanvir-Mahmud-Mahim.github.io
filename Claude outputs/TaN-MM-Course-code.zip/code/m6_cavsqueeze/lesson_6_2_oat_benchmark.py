"""Module 6, Lesson 6.2 -- The exact one-axis-twisting benchmark
(cavsqueeze).

`oat_closed_form` gives the exact unitary Kitagawa-Ueda moments for N
spins -- the decoherence-free benchmark every dissipative solver is
judged against. We reproduce the textbook N^(-2/3) scaling of the
optimal squeezing and check the closed form's own internal identity
xi2_R = xi2_S (N/2)^2 / <Jx>^2.
"""
import numpy as np

from cavsqueeze import metrological_gain_db, oat_closed_form

print(" N     | xi2_S(opt)  | gain (dB)")
opt = {}
for N in (100, 1000, 10000):
    mus = np.linspace(0.2, 8.0, 400) * N ** (-2.0 / 3.0)
    best = min((oat_closed_form(N, mu) for mu in mus),
               key=lambda o: o["xi2_S"])
    opt[N] = best
    print(f" {N:5d} | {best['xi2_S']:.5f}    | "
          f"{metrological_gain_db(best['xi2_R']):.2f}")

# Kitagawa-Ueda: optimal xi2_S scales as N^(-2/3) (up to a constant)
r1 = opt[1000]["xi2_S"] / opt[100]["xi2_S"]
r2 = opt[10000]["xi2_S"] / opt[1000]["xi2_S"]
print(f"xi2 ratio per decade of N: {r1:.3f}, {r2:.3f}  "
      f"(N^(-2/3) predicts {10 ** (-2 / 3):.3f})")
assert abs(r1 - 10 ** (-2 / 3)) < 0.05
assert abs(r2 - 10 ** (-2 / 3)) < 0.02

# internal identity of the closed form
o = oat_closed_form(200, 0.03)
lhs = o["xi2_R"]
rhs = o["xi2_S"] * (200 / 2.0) ** 2 / o["Jx"] ** 2
print(f"xi2_R identity: {lhs:.6f} == {rhs:.6f}")
assert abs(lhs - rhs) < 1e-12
print("OK: lesson 6.2 complete")
