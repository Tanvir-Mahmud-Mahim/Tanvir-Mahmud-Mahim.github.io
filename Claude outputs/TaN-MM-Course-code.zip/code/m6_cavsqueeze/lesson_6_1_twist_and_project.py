"""Module 6, Lesson 6.1 -- Cavity-mediated spin squeezing and its
metrology projections (cavsqueeze).

A dispersively coupled cavity mediates one-axis twisting of a spin
ensemble. The class-resolved cumulant solver evolves the collective
moments; the metrology module turns them into the numbers a clock is
designed against: Wineland parameter, phase sensitivity, and the
projection-noise-limited Allan deviation.
"""
import numpy as np

import cavsqueeze as cs
from cavsqueeze import (clock_allan_deviation, css_x, from_hz,
                        homogeneous, metrological_gain_db,
                        squeezing_after, squeezing_parameters)
from cavsqueeze.cumulant import Rates

print(f"cavsqueeze version: {cs.__version__}")

# --- coherent-spin-state baseline: the standard quantum limit ------
N = 1e8
ens = homogeneous(N)
p = from_hz(g_hz=1e6 / np.sqrt(N), kappa_hz=1e4, Delta_hz=30e6,
            T=0.02, T2=0.15)
rt = Rates.from_params(p, ens)
m0 = squeezing_parameters(css_x(rt.M), rt.n)
print(f"CSS baseline: xi2_R = {m0['xi2_R']:.4f}, contrast = "
      f"{m0['contrast']:.4f}, dphi = {m0['dphi']:.3e} "
      f"(SQL 1/sqrt(N) = {1 / np.sqrt(N):.3e})")
assert np.isclose(m0["xi2_R"], 1.0) and np.isclose(m0["dphi"],
                                                   1 / np.sqrt(N))

# --- twist, with an echo, and read the squeezing --------------------
res = squeezing_after(p, ens, t=5e-5, echo=True)
print(f"after t = 50 us echo twist: xi2_R = {res['xi2']:.4f}, "
      f"contrast = {res['contrast']:.4f}")
gain = metrological_gain_db(res["xi2"])
print(f"metrological gain: {gain:.2f} dB over the SQL")
assert res["xi2"] < 1.0 and gain > 0.0

# --- project onto a clock ------------------------------------------
# dphi of the squeezed state, then the Allan deviation of a Ramsey
# clock at nu0 = 429 THz (Sr) with T_R = 100 ms, at tau = 1 s.
dphi_sq = np.sqrt(res["var_min"]) / (res["contrast"] * N / 2.0)
for label, dphi in (("SQL", 1 / np.sqrt(N)), ("squeezed", dphi_sq)):
    sy = clock_allan_deviation(dphi, nu0=4.29e14, T_ramsey=0.1, tau=1.0)
    print(f"  sigma_y(1 s), {label:8s}: {sy:.3e}")
assert dphi_sq < 1 / np.sqrt(N)
print("OK: lesson 6.1 complete")
