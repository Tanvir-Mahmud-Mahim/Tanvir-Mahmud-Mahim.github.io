"""Module 6, Lesson 6.3 -- Squeezing from measured count data
(cavsqueeze v1.11).

Every other module predicts; this one estimates from an experiment.
We simulate the standard Ramsey tomography record -- per-angle shots
of the population difference J_z -- from the EXACT one-axis-twisting
covariance, then hand only the counts to `estimate_squeezing` and
compare its answer against the closed form it has never seen.
"""
import numpy as np

from cavsqueeze import (estimate_squeezing, metrological_gain_db,
                        oat_closed_form)

# --- ground truth: exact OAT state of N = 100 spins -----------------
N, mu = 100, 0.05
oat = oat_closed_form(N, mu)
contrast_true = 2.0 * oat["Jx"] / N
print(f"truth: Vmin = {oat['Vmin']:.4f}, xi2_R = {oat['xi2_R']:.4f}, "
      f"contrast = {contrast_true:.4f}")

# transverse covariance in the (y, z) tomography plane
a0 = oat["alpha_min"]
R = np.array([[np.cos(a0), -np.sin(a0)], [np.sin(a0), np.cos(a0)]])
cov = R @ np.diag([oat["Vmin"], oat["Vmax"]]) @ R.T


def v_theta(th):
    u = np.array([np.cos(th), np.sin(th)])
    return float(u @ cov @ u)


# --- "measure": M shots of J_z at each tomography angle -------------
rng = np.random.default_rng(0)
angles = np.linspace(0.0, np.pi, 12, endpoint=False)
M = 4000
shots = [rng.normal(0.0, np.sqrt(v_theta(t)), M) for t in angles]

# --- estimate from the counts alone ---------------------------------
est = estimate_squeezing(angles, shots, N, contrast=contrast_true)
print(f"estimated: V_min = {est.var_min:.4f} +/- {est.var_min_sigma:.4f}"
      f"  (truth {oat['Vmin']:.4f})")
print(f"estimated: xi2_R = {est.xi2_R:.4f} +/- {est.xi2_R_sigma:.4f}"
      f"  (truth {oat['xi2_R']:.4f})")
print(f"gain: {metrological_gain_db(est.xi2_R):.2f} dB "
      f"(truth {metrological_gain_db(oat['xi2_R']):.2f})")
d = (est.theta_min - a0) % np.pi
print(f"dip angle error (mod pi): {min(d, np.pi - d):.4f} rad")
assert abs(est.var_min - oat["Vmin"]) < 4 * est.var_min_sigma
assert abs(est.xi2_R - oat["xi2_R"]) < 4 * est.xi2_R_sigma
assert est.xi2_R < 1.0

# --- detection noise: subtract it or answer the wrong question ------
vdet = 2.0                                   # known detector variance
shots_noisy = [s + rng.normal(0.0, np.sqrt(vdet), M) for s in shots]
raw = estimate_squeezing(angles, shots_noisy, N, contrast=contrast_true)
corr = estimate_squeezing(angles, shots_noisy, N, contrast=contrast_true,
                          detection_variance=vdet)
print(f"with detector noise: raw xi2_R = {raw.xi2_R:.3f}, "
      f"corrected = {corr.xi2_R:.3f} (truth {oat['xi2_R']:.3f})")
assert abs(corr.xi2_R - oat["xi2_R"]) < 5 * corr.xi2_R_sigma
assert raw.xi2_R > corr.xi2_R              # noise masquerades as anti-squeezing
print("OK: lesson 6.3 complete")
