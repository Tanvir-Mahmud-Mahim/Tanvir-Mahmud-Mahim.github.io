"""Module 5, Lesson 5.1 -- Junction recipes and the short-junction
ensemble (absnoise).

The six cited graphene-junction contact recipes (Jung et al.,
arXiv:2503.06850, Table I) drive the closed-form short-junction
ensemble: Andreev levels, critical current, and the intrinsic
occupation-noise limit of Andreev thermometry -- the Cauchy-Schwarz
bound var(T) >= 2 kB T^2 tauA / (C_A t), which uniform-transparency
short junctions saturate exactly.
"""
import numpy as np

import absnoise as ab

print(f"absnoise version: {ab.__version__}")

print(f"{len(ab.RECIPES)} cited junction recipes:")
for r in ab.RECIPES:
    print(f"  {r.label:12s} Tc* = {r.Tc:4.2f} K, tau = {r.tau:.2f}, "
          f"Ic(20 mK) = {r.Ic20 * 1e6:.2f} uA")

# --- the Ti/Al/Au junction -----------------------------------------
rec = ab.RECIPES[1]
sj = ab.ShortJunction(rec)
sj.calibrate(T0=0.02)                      # match the measured Ic(20 mK)
print(f"\n{rec.label}: calibrated scale = {sj.scale:.3f}, "
      f"channels Nch = {sj.Nch}")
Ic20 = sj.Ic(0.02)
print(f"Ic(20 mK) after calibration: {Ic20 * 1e6:.3f} uA "
      f"(measured {rec.Ic20 * 1e6:.2f})")
assert abs(Ic20 - rec.Ic20) / rec.Ic20 < 1e-9

# Ic falls with temperature (BCS gap + thermal occupation)
for T in (0.10, 0.30, 0.50):
    print(f"  Ic({T:.2f} K) = {sj.Ic(T) * 1e6:.3f} uA")
assert sj.Ic(0.5) < sj.Ic(0.1)

# --- the occupation-noise temperature bound ------------------------
T, tauA, t_int = 0.15, 1e-6, 1e-3          # K, s (occupation lag), s
achieved, bound, sums = sj.temperature_bound(T, tauA, t_int)
print(f"\nAndreev thermometry at T = {T} K, tauA = {tauA * 1e6:.0f} us, "
      f"t = {t_int * 1e3:.0f} ms:")
print(f"  achieved dT = {achieved * 1e6:.2f} uK")
print(f"  bound    dT = {bound * 1e6:.2f} uK  "
      f"(Cauchy-Schwarz over channels)")
print(f"  Andreev heat capacity C_A = {sums['C_A'] / ab.KB:.1f} kB")
# uniform-transparency short junctions SATURATE the bound
assert abs(achieved - bound) / bound < 1e-6
print("bound saturated exactly, as the ensemble structure demands")
print("OK: lesson 5.1 complete")
