"""Module 5, Lesson 5.3 -- Fit your own junction from a measured Ic(T)
curve (absnoise v0.6).

Your junction is not in the shipped recipe table. The standard
characterization measurement -- critical current versus temperature --
determines (Ic0, Tc*, tau), and `fit_ic_curve` fits the package's own
short-junction ensemble to it, with honest uncertainties. The fitted
recipe then re-enters every budget in the package.
"""
import numpy as np

import absnoise as ab

# --- "measure" an Ic(T) curve ---------------------------------------
# We synthesize data from the model with realistic noise, so the
# generating parameters are known and the fit can be judged.
Ic0_true, Tc_true, tau_true = 2.0e-6, 0.75, 0.78
T_data = np.linspace(0.05, 0.65, 12)
sigma_Ic = 0.01 * Ic0_true                          # 1 percent noise
rng = np.random.default_rng(5)
Ic_data = (ab.ic_model(T_data, Ic0_true, Tc_true, tau_true)
           + rng.normal(0.0, sigma_Ic, T_data.size))

# --- fit -------------------------------------------------------------
fit = ab.fit_ic_curve(T_data, Ic_data, sigma_Ic=sigma_Ic)
print("fitted junction parameters (generating values in brackets):")
print(f"  Ic0 = {fit.Ic0 * 1e6:.3f} +/- {fit.sigma['Ic0'] * 1e6:.3f} uA "
      f"[{Ic0_true * 1e6:.2f}]")
print(f"  Tc  = {fit.Tc:.4f} +/- {fit.sigma['Tc']:.4f} K   [{Tc_true}]")
print(f"  tau = {fit.tau:.4f} +/- {fit.sigma['tau']:.4f}    [{tau_true}]")
print(f"  chi2/dof = {fit.chi2 / fit.chi2_dof:.2f}  (near 1: model and "
      f"stated noise consistent)")
assert abs(fit.Ic0 - Ic0_true) < 3 * fit.sigma['Ic0']
assert abs(fit.Tc - Tc_true) < 3 * fit.sigma['Tc']
assert abs(fit.tau - tau_true) < 3 * fit.sigma['tau']

# --- package the fit as a Recipe and re-enter the pipeline -----------
# geometry and gating are YOUR measured values; an Ic(T) curve does
# not determine them, and to_recipe does not pretend it does.
rec = fit.to_recipe(name="my Ti/Al stack", label="mine", xi=5e-6,
                    L=0.2e-6, W=2e-6, Vbg=30.0, Rn=50.0)
sj = ab.ShortJunction(rec)
sj.calibrate()
achieved, bound, _ = sj.temperature_bound(0.15, 1e-6, 1e-3)
print(f"\nthermometry bound of the FITTED junction at 150 mK: "
      f"dT = {bound * 1e6:.0f} uK")
assert np.isfinite(bound) and bound > 0

# --- what plateau-only data cannot tell you -------------------------
import warnings
T_low = np.linspace(0.02, 0.10, 8)                  # never leaves plateau
y_low = ab.ic_model(T_low, Ic0_true, Tc_true, tau_true)
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter("always")
    ab.fit_ic_curve(T_low, y_low, sigma_Ic=1e-9)
    msgs = [str(x.message) for x in w]
print(f"plateau-only data -> warning issued: "
      f"{any('weakly determined' in m for m in msgs)}")
assert any("weakly determined" in m for m in msgs)
print("OK: lesson 5.3 complete")
