"""Module 5, Lesson 5.2 -- Telegraph noise and full detector budgets
(absnoise).

Occupation noise is telegraph noise: a Monte-Carlo trace of switching
channels must show the Lorentzian PSD the master equation predicts.
`SensorBudget` then assembles the device-level numbers an experiment
is designed against: thermometry resolution, resonator frequency
noise, and matched-filter calorimetric energy resolution -- checked
against its own closed-form anchor.
"""
import numpy as np

import absnoise as ab

rec = ab.RECIPES[1]                        # Ti/Al/Au
T = 0.15                                   # K
tauA = 1e-6                                # occupation correlation time (s)

# --- telegraph Monte Carlo vs the Lorentzian plateau ----------------
rng = np.random.default_rng(0)
f_occ = 0.25                               # channel occupation factor
dt, n_steps, n_ch = 2e-8, 200000, 40
x = ab.telegraph_traces(f_occ, tauA, dt, n_steps, n_ch, rng)
freqs, psd = ab.psd_single_sided(x.sum(axis=1).astype(float), dt)
# analytic single-sided plateau of n_ch two-state channels:
# S(0) = n_ch * 4 var tauA, var = f(1-f)
S0_analytic = n_ch * 4.0 * f_occ * (1 - f_occ) * tauA
plateau = psd[(freqs > 1e3) & (freqs < 3e4)].mean()
print(f"telegraph PSD plateau: {plateau:.3e}  "
      f"(analytic {S0_analytic:.3e})")
assert abs(plateau - S0_analytic) / S0_analytic < 0.25   # statistics-limited

# --- the device budget ---------------------------------------------
b = ab.SensorBudget(rec)
Ce = b.Ce(T)
print(f"\nSensorBudget for {rec.label} at T = {T} K:")
print(f"  electron heat capacity Ce  : {Ce / ab.KB:.1f} kB")
print(f"  thermal time tau_th        : {b.tau_th(T) * 1e9:.2f} ns")
print(f"  Josephson inductance L_J   : {b.LJ(T) * 1e9:.3f} nH")
print(f"  resonator participation    : {b.participation(T):.4f}")

t_int = 1e-3
dTa, _ = b.dT_andreev(T, tauA, t_int)
dTp = b.dT_phonon(T, t_int)
print(f"  dT (Andreev, 1 ms)         : {dTa * 1e6:.1f} uK")
print(f"  dT (phonon TFN, 1 ms)      : {dTp * 1e6:.1f} uK")

# --- calorimetry: numeric matched filter vs closed form -------------
sE = b.energy_resolution(T, tauA)
sE_analytic = b.energy_resolution_analytic_A(T, tauA)
eV = 1.602176634e-19
print(f"  energy resolution (full)   : {sE / eV * 1e3:.2f} meV")
print(f"  Andreev-only closed form   : {sE_analytic / eV * 1e3:.2f} meV")
# the full budget can only be worse than the single-noise closed form
assert sE >= 0.9 * sE_analytic
print("OK: lesson 5.2 complete")
